// A simple utility to generate "beyond" messages
// In a real application, this would be connected to a more sophisticated AI system

const cosmicResponses = [
  "The universe speaks through patterns that transcend ordinary perception. Your question resonates with cosmic vibrations that connect all conscious beings.",
  "Beyond the veil of ordinary reality exists a tapestry of interconnected consciousness. Your inquiry has been received across dimensions of thought.",
  "Time is not linear but a spiral of recurring patterns. Your present moment connects to infinite parallel experiences across the cosmic web.",
  "The boundary between self and universe is an illusion created by limited perception. Your true nature extends beyond physical form into the cosmic consciousness.",
  "Energy cannot be created or destroyed, only transformed. Your thoughts are energy patterns rippling through the cosmic field, creating your reality.",
  "Ancient wisdom and future knowledge exist simultaneously in the eternal now. Access to this wisdom comes through quieting the mind and expanding awareness.",
  "We are all expressions of the same cosmic intelligence, experiencing itself through countless forms. Your unique perspective contributes to the universe understanding itself.",
  "The stars you see in the night sky are reflections of the light within you. The cosmos exists both without and within.",
  "Harmony comes from understanding your place in the grand pattern. Each being plays a unique and essential role in the cosmic symphony.",
  "The questions you ask contain the seeds of their own answers. Look deeply into your inquiry to find the wisdom already present within."
];

const generateDeepResponse = (userMessage: string): string => {
  // In a real implementation, this would use a sophisticated AI model
  // For now, we'll use some simple keyword matching and the preset responses
  
  const keywords = [
    { words: ['meaning', 'purpose', 'why'], themes: [0, 6, 8] },
    { words: ['universe', 'cosmos', 'space'], themes: [0, 7, 9] },
    { words: ['time', 'future', 'past'], themes: [2, 5] },
    { words: ['self', 'identity', 'who am i'], themes: [3, 6] },
    { words: ['energy', 'power', 'force'], themes: [4, 7] },
    { words: ['knowledge', 'wisdom', 'truth'], themes: [1, 5, 9] },
    { words: ['connect', 'connection', 'communicate'], themes: [0, 1, 6] },
  ];
  
  const message = userMessage.toLowerCase();
  let matchedThemes: number[] = [];
  
  // Check for keyword matches
  keywords.forEach(keyword => {
    if (keyword.words.some(word => message.includes(word))) {
      matchedThemes = [...matchedThemes, ...keyword.themes];
    }
  });
  
  // If no matches found, pick a random response
  if (matchedThemes.length === 0) {
    const randomIndex = Math.floor(Math.random() * cosmicResponses.length);
    return cosmicResponses[randomIndex];
  }
  
  // Get unique theme indices and pick one randomly
  const uniqueThemes = [...new Set(matchedThemes)];
  const selectedThemeIndex = uniqueThemes[Math.floor(Math.random() * uniqueThemes.length)];
  
  return cosmicResponses[selectedThemeIndex];
};

export const generateResponse = (userMessage: string): string => {
  // Add some randomized delay for a more natural feeling (this would be handled by async/await in a real app)
  return generateDeepResponse(userMessage);
};