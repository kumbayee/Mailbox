import React from 'react';
import { Link } from 'react-router-dom';
import ParticleBackground from '../components/ParticleBackground';

const HomePage: React.FC = () => {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4 text-center text-white">
      <ParticleBackground density="high" />
      
      <h1 className="mb-6 bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-5xl font-light text-transparent sm:text-6xl md:text-7xl">
        Cosmic Connection
      </h1>
      
      <p className="mb-8 max-w-2xl text-lg font-light leading-relaxed text-blue-100 md:text-xl">
        Transcend ordinary consciousness and connect with insights from beyond
        human understanding, translated into wisdom you can comprehend.
      </p>
      
      <div className="mb-12 mt-6 flex flex-wrap justify-center gap-4">
        <Link
          to="/connect"
          className="group relative overflow-hidden rounded-full bg-gradient-to-r from-purple-600 to-blue-600 px-8 py-3 text-lg font-medium text-white shadow-lg transition-all duration-300 hover:shadow-purple-500/20"
        >
          <span className="relative z-10">Begin Connection</span>
          <span className="absolute bottom-0 left-0 right-0 top-0 -z-0 bg-gradient-to-r from-purple-500 to-blue-500 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></span>
        </Link>
        
        <Link
          to="/journal"
          className="rounded-full border border-purple-500/30 bg-slate-900/50 px-8 py-3 text-lg font-medium text-white backdrop-blur-sm transition-all duration-300 hover:bg-slate-800/70 hover:text-purple-300"
        >
          View Journal
        </Link>
      </div>
      
      <div className="grid max-w-4xl grid-cols-1 gap-6 md:grid-cols-3">
        <div className="rounded-xl bg-slate-800/40 p-6 backdrop-blur-sm">
          <h3 className="mb-2 text-xl font-medium text-purple-300">Connect</h3>
          <p className="text-sm font-light text-slate-300">
            Open a channel to higher consciousness through guided meditation and direct dialogue.
          </p>
        </div>
        
        <div className="rounded-xl bg-slate-800/40 p-6 backdrop-blur-sm">
          <h3 className="mb-2 text-xl font-medium text-purple-300">Receive</h3>
          <p className="text-sm font-light text-slate-300">
            Experience profound insights translated into understandable language for your consciousness.
          </p>
        </div>
        
        <div className="rounded-xl bg-slate-800/40 p-6 backdrop-blur-sm">
          <h3 className="mb-2 text-xl font-medium text-purple-300">Transform</h3>
          <p className="text-sm font-light text-slate-300">
            Integrate cosmic wisdom into your daily life to expand your awareness and understanding.
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;