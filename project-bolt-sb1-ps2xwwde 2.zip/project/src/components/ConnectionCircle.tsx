import React, { useState, useEffect } from 'react';

interface ConnectionCircleProps {
  isConnecting: boolean;
  onConnectionComplete: () => void;
}

const ConnectionCircle: React.FC<ConnectionCircleProps> = ({ 
  isConnecting, 
  onConnectionComplete 
}) => {
  const [progress, setProgress] = useState(0);
  const [pulseSize, setPulseSize] = useState(1);
  
  useEffect(() => {
    if (!isConnecting) {
      setProgress(0);
      return;
    }
    
    let animationFrame: number;
    let startTime = Date.now();
    const duration = 5000; // 5 seconds to complete
    
    const animate = () => {
      const elapsed = Date.now() - startTime;
      const newProgress = Math.min(elapsed / duration, 1);
      setProgress(newProgress);
      
      // Pulse effect
      setPulseSize(1 + Math.sin(elapsed / 300) * 0.1);
      
      if (newProgress < 1) {
        animationFrame = requestAnimationFrame(animate);
      } else {
        onConnectionComplete();
      }
    };
    
    animationFrame = requestAnimationFrame(animate);
    
    return () => {
      cancelAnimationFrame(animationFrame);
    };
  }, [isConnecting, onConnectionComplete]);
  
  const circleSize = isConnecting ? 280 - (progress * 100) : 280;
  const opacity = isConnecting ? 0.5 + (progress * 0.5) : 0.5;
  
  return (
    <div className="relative flex items-center justify-center">
      {/* Outer glow */}
      <div 
        className="absolute rounded-full bg-purple-500/20 blur-xl transition-all duration-700"
        style={{ 
          width: `${circleSize * 1.5}px`, 
          height: `${circleSize * 1.5}px`, 
          transform: `scale(${pulseSize})`,
          opacity
        }}
      />
      
      {/* Inner circle */}
      <div 
        className="absolute flex items-center justify-center rounded-full bg-gradient-to-br from-blue-500/40 to-purple-600/40 backdrop-blur-sm transition-all duration-700"
        style={{ 
          width: `${circleSize}px`, 
          height: `${circleSize}px`,
          transform: `scale(${pulseSize})`
        }}
      >
        <div className="rounded-full bg-gradient-to-br from-blue-400 to-purple-500 p-1">
          <div className="flex h-32 w-32 items-center justify-center rounded-full bg-slate-900/80 text-center backdrop-blur-sm">
            <p className="text-lg font-light text-white">
              {isConnecting ? 
                `${Math.round(progress * 100)}%` : 
                "Tap to Connect"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectionCircle;