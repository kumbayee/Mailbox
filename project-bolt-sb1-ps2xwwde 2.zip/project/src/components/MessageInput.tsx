import React, { useState, useRef, useEffect } from 'react';

interface MessageInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage, disabled = false }) => {
  const [message, setMessage] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  useEffect(() => {
    if (!disabled && inputRef.current) {
      inputRef.current.focus();
    }
  }, [disabled]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message);
      setMessage('');
    }
  };
  
  const handleTextareaKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };
  
  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    
    // Auto-resize the textarea
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`;
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="relative">
      <textarea
        ref={inputRef}
        value={message}
        onChange={handleTextareaChange}
        onKeyDown={handleTextareaKeyDown}
        placeholder={disabled ? "Connection inactive..." : "Type your message..."}
        disabled={disabled}
        className={`w-full resize-none overflow-hidden rounded-full bg-slate-800/70 px-4 py-3 pr-12 text-white placeholder-slate-400 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-purple-500/50 ${
          disabled ? 'opacity-50' : ''
        }`}
        rows={1}
      />
      <button
        type="submit"
        disabled={disabled || !message.trim()}
        className={`absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 p-2 text-white transition-all duration-200 ${
          disabled || !message.trim() 
            ? 'cursor-not-allowed opacity-50' 
            : 'hover:from-purple-600 hover:to-indigo-600'
        }`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M22 2L11 13M22 2L15 22L11 13L2 9L22 2Z" />
        </svg>
      </button>
    </form>
  );
};

export default MessageInput;