import React, { useState } from 'react';
import { JournalEntry as JournalEntryType } from '../types';

interface JournalEntryProps {
  entry: JournalEntryType;
  onDelete: (id: string) => void;
  onUpdate: (id: string, content: string) => void;
}

const JournalEntry: React.FC<JournalEntryProps> = ({ entry, onDelete, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(entry.content);
  
  const handleSave = () => {
    if (editContent.trim()) {
      onUpdate(entry.id, editContent);
      setIsEditing(false);
    }
  };
  
  const formattedDate = new Date(entry.date).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });
  
  return (
    <div className="mb-6 rounded-xl bg-slate-800/60 p-5 backdrop-blur-md transition-all duration-300 hover:bg-slate-800/80">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center">
          <span className="text-sm font-medium text-white/70">{formattedDate}</span>
          <div className="ml-3 flex">
            {entry.tags.map(tag => (
              <span 
                key={tag}
                className="mr-2 rounded-full bg-indigo-900/60 px-2 py-1 text-xs text-blue-200"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        
        <div className="flex">
          {isEditing ? (
            <>
              <button 
                onClick={handleSave}
                className="mr-2 rounded bg-green-600/80 px-2 py-1 text-xs text-white hover:bg-green-600"
              >
                Save
              </button>
              <button 
                onClick={() => {
                  setIsEditing(false);
                  setEditContent(entry.content);
                }}
                className="rounded bg-slate-600/80 px-2 py-1 text-xs text-white hover:bg-slate-600"
              >
                Cancel
              </button>
            </>
          ) : (
            <>
              <button 
                onClick={() => setIsEditing(true)}
                className="mr-2 rounded bg-slate-600/80 px-2 py-1 text-xs text-white hover:bg-slate-600"
              >
                Edit
              </button>
              <button 
                onClick={() => onDelete(entry.id)}
                className="rounded bg-red-700/80 px-2 py-1 text-xs text-white hover:bg-red-700"
              >
                Delete
              </button>
            </>
          )}
        </div>
      </div>
      
      {isEditing ? (
        <textarea
          value={editContent}
          onChange={(e) => setEditContent(e.target.value)}
          className="mt-2 h-32 w-full rounded-lg bg-slate-700/60 p-3 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
          placeholder="Write your journal entry..."
          autoFocus
        />
      ) : (
        <p className="whitespace-pre-wrap text-white">{entry.content}</p>
      )}
    </div>
  );
};

export default JournalEntry;