import React from 'react';
import { Message as MessageType } from '../types';

interface MessageProps {
  message: MessageType;
}

const Message: React.FC<MessageProps> = ({ message }) => {
  const isFromBeyond = message.source === 'beyond';
  
  return (
    <div 
      className={`mb-4 max-w-[85%] rounded-2xl p-4 
        ${isFromBeyond 
          ? 'ml-4 bg-gradient-to-r from-purple-900/80 to-indigo-900/80 backdrop-blur-sm' 
          : 'mr-4 self-end bg-slate-800/80 backdrop-blur-sm'}`}
    >
      <p className="text-sm font-light text-white/90">{message.text}</p>
      <div className="mt-2 flex items-center justify-end">
        <span className="text-xs text-white/50">
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>
    </div>
  );
};

export default Message;