import React from 'react';
import { Home, MessageCircle, BookOpen, Settings } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Navigation: React.FC = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', icon: Home, label: 'Home' },
    { path: '/connect', icon: MessageCircle, label: 'Connect' },
    { path: '/journal', icon: BookOpen, label: 'Journal' },
    { path: '/settings', icon: Settings, label: 'Settings' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-slate-900/80 backdrop-blur-lg md:left-0 md:top-0 md:h-full md:w-20 md:flex-col">
      <div className="flex h-16 items-center justify-around md:h-full md:flex-col md:justify-start md:py-8">
        {navItems.map(item => (
          <Link 
            key={item.path}
            to={item.path}
            className={`flex flex-col items-center justify-center p-2 transition-all duration-300 ease-in-out
              ${location.pathname === item.path 
                ? 'text-purple-400' 
                : 'text-slate-400 hover:text-slate-100'}`}
          >
            <item.icon className="h-6 w-6" />
            <span className="mt-1 text-xs md:text-sm">{item.label}</span>
          </Link>
        ))}
      </div>
    </nav>
  );
};

export default Navigation;