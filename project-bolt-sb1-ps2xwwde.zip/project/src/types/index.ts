export interface Message {
  id: string;
  text: string;
  source: 'user' | 'beyond';
  timestamp: Date;
}

export interface JournalEntry {
  id: string;
  content: string;
  date: Date;
  tags: string[];
}

export interface EnvironmentSettings {
  theme: 'cosmic' | 'ethereal' | 'celestial' | 'earthly';
  particleDensity: 'low' | 'medium' | 'high';
  soundscape: 'silence' | 'ambient' | 'cosmic' | 'nature';
  brightness: number; // 0-100
}