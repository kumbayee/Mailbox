import React, { useState, useEffect } from 'react';
import ParticleBackground from '../components/ParticleBackground';
import { EnvironmentSettings } from '../types';

const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<EnvironmentSettings>({
    theme: 'cosmic',
    particleDensity: 'medium',
    soundscape: 'ambient',
    brightness: 50
  });
  
  // Load settings from localStorage on component mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('cosmicConnectionSettings');
    if (savedSettings) {
      try {
        setSettings(JSON.parse(savedSettings));
      } catch (error) {
        console.error('Error parsing saved settings:', error);
      }
    }
  }, []);
  
  // Save settings to localStorage when they change
  useEffect(() => {
    localStorage.setItem('cosmicConnectionSettings', JSON.stringify(settings));
  }, [settings]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleRangeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSettings(prev => ({
      ...prev,
      [name]: parseInt(value, 10)
    }));
  };
  
  return (
    <div className="flex min-h-screen flex-col md:pl-20">
      <ParticleBackground density="low" />
      
      <main className="container mx-auto max-w-2xl flex-1 px-4 py-8">
        <h1 className="mb-8 bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-3xl font-light text-transparent md:text-4xl">
          Connection Settings
        </h1>
        
        <div className="rounded-xl bg-slate-800/60 p-6 backdrop-blur-md">
          <div className="mb-6">
            <label className="mb-2 block text-lg font-medium text-white">Visual Theme</label>
            <select
              name="theme"
              value={settings.theme}
              onChange={handleChange}
              className="w-full rounded-lg bg-slate-700/60 p-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50"
            >
              <option value="cosmic">Cosmic (Deep Space)</option>
              <option value="ethereal">Ethereal (Light & Airy)</option>
              <option value="celestial">Celestial (Stars & Nebulae)</option>
              <option value="earthly">Earthly (Natural Elements)</option>
            </select>
            <p className="mt-1 text-sm text-slate-400">
              Changes the visual appearance of your connection space
            </p>
          </div>
          
          <div className="mb-6">
            <label className="mb-2 block text-lg font-medium text-white">Particle Density</label>
            <div className="flex items-center">
              <input
                type="radio"
                id="density-low"
                name="particleDensity"
                value="low"
                checked={settings.particleDensity === 'low'}
                onChange={handleChange}
                className="h-4 w-4 accent-purple-500"
              />
              <label htmlFor="density-low" className="ml-2 mr-6 text-white">Low</label>
              
              <input
                type="radio"
                id="density-medium"
                name="particleDensity"
                value="medium"
                checked={settings.particleDensity === 'medium'}
                onChange={handleChange}
                className="h-4 w-4 accent-purple-500"
              />
              <label htmlFor="density-medium" className="ml-2 mr-6 text-white">Medium</label>
              
              <input
                type="radio"
                id="density-high"
                name="particleDensity"
                value="high"
                checked={settings.particleDensity === 'high'}
                onChange={handleChange}
                className="h-4 w-4 accent-purple-500"
              />
              <label htmlFor="density-high" className="ml-2 text-white">High</label>
            </div>
            <p className="mt-1 text-sm text-slate-400">
              Adjusts the number of particles in the background
            </p>
          </div>
          
          <div className="mb-6">
            <label className="mb-2 block text-lg font-medium text-white">Soundscape</label>
            <select
              name="soundscape"
              value={settings.soundscape}
              onChange={handleChange}
              className="w-full rounded-lg bg-slate-700/60 p-3 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50"
            >
              <option value="silence">Silence</option>
              <option value="ambient">Ambient</option>
              <option value="cosmic">Cosmic Frequencies</option>
              <option value="nature">Natural Elements</option>
            </select>
            <p className="mt-1 text-sm text-slate-400">
              Background sounds to enhance your connection experience
            </p>
          </div>
          
          <div className="mb-6">
            <label className="mb-2 block text-lg font-medium text-white">
              Display Brightness: {settings.brightness}%
            </label>
            <input
              type="range"
              name="brightness"
              min="10"
              max="100"
              value={settings.brightness}
              onChange={handleRangeChange}
              className="h-2 w-full appearance-none rounded-lg bg-slate-700"
            />
            <p className="mt-1 text-sm text-slate-400">
              Adjusts the overall brightness of the interface
            </p>
          </div>
          
          <div className="mt-8 border-t border-slate-600 pt-6">
            <h2 className="mb-4 text-xl font-medium text-white">Account Preferences</h2>
            
            <div className="mb-6 flex items-center">
              <input
                type="checkbox"
                id="save-journal"
                className="h-4 w-4 accent-purple-500"
                defaultChecked={true}
              />
              <label htmlFor="save-journal" className="ml-2 text-white">
                Save journal entries locally
              </label>
            </div>
            
            <div className="mb-6 flex items-center">
              <input
                type="checkbox"
                id="save-history"
                className="h-4 w-4 accent-purple-500"
                defaultChecked={true}
              />
              <label htmlFor="save-history" className="ml-2 text-white">
                Save connection history
              </label>
            </div>
            
            <button className="rounded-lg bg-red-700/80 px-4 py-2 font-medium text-white hover:bg-red-700">
              Clear All Data
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default SettingsPage;