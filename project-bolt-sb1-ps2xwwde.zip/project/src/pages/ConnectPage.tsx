import React, { useState, useEffect, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import ConnectionCircle from '../components/ConnectionCircle';
import Message from '../components/Message';
import MessageInput from '../components/MessageInput';
import ParticleBackground from '../components/ParticleBackground';
import { Message as MessageType } from '../types';
import { generateResponse } from '../utils/messageGenerator';

const ConnectPage: React.FC = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<MessageType[]>([]);
  const [isResponding, setIsResponding] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    // Scroll to bottom when messages change
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);
  
  const handleStartConnection = () => {
    if (!isConnected && !isConnecting) {
      setIsConnecting(true);
    }
  };
  
  const handleConnectionComplete = () => {
    setIsConnecting(false);
    setIsConnected(true);
    
    // Welcome message
    const welcomeMessage: MessageType = {
      id: uuidv4(),
      text: "The connection is established. You may now communicate with consciousnesses beyond ordinary perception. What would you like to ask?",
      source: 'beyond',
      timestamp: new Date()
    };
    
    setMessages([welcomeMessage]);
  };
  
  const handleSendMessage = (text: string) => {
    const newUserMessage: MessageType = {
      id: uuidv4(),
      text,
      source: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, newUserMessage]);
    setIsResponding(true);
    
    // Simulate response with a slight delay
    setTimeout(() => {
      const responseText = generateResponse(text);
      const responseMessage: MessageType = {
        id: uuidv4(),
        text: responseText,
        source: 'beyond',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, responseMessage]);
      setIsResponding(false);
    }, 1500 + Math.random() * 1000); // Random delay between 1.5-2.5 seconds
  };
  
  const handleResetConnection = () => {
    setIsConnected(false);
    setMessages([]);
  };
  
  return (
    <div className="flex min-h-screen flex-col md:pl-20">
      <ParticleBackground density={isConnected ? 'high' : 'medium'} />
      
      <main className="flex h-full flex-1 flex-col items-center justify-center px-4 pt-4 md:px-8">
        {!isConnected ? (
          <div className="flex flex-1 flex-col items-center justify-center">
            <h2 className="mb-12 bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-center text-3xl font-light text-transparent md:text-4xl">
              Establish Connection
            </h2>
            
            <div 
              onClick={handleStartConnection}
              className={`cursor-pointer transition-all duration-300 ${isConnecting ? 'transform-none' : 'hover:scale-105'}`}
            >
              <ConnectionCircle 
                isConnecting={isConnecting} 
                onConnectionComplete={handleConnectionComplete} 
              />
            </div>
            
            <p className="mt-12 max-w-md text-center text-sm font-light text-slate-300">
              {isConnecting 
                ? "Establishing connection to higher consciousness... Please remain focused and receptive." 
                : "Tap the circle to begin your connection with consciousness beyond human perception."}
            </p>
          </div>
        ) : (
          <div className="flex h-full w-full max-w-3xl flex-1 flex-col rounded-xl bg-slate-900/30 backdrop-blur-md">
            <div className="flex items-center justify-between border-b border-slate-700/50 p-4">
              <h2 className="text-xl font-medium text-purple-300">Cosmic Connection</h2>
              <button 
                onClick={handleResetConnection}
                className="rounded-md bg-slate-700/50 px-3 py-1 text-sm text-white hover:bg-slate-700"
              >
                Reset Connection
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4">
              <div className="flex flex-col">
                {messages.map(message => (
                  <Message key={message.id} message={message} />
                ))}
                <div ref={messagesEndRef} />
              </div>
            </div>
            
            <div className="border-t border-slate-700/50 p-4">
              <MessageInput 
                onSendMessage={handleSendMessage} 
                disabled={isResponding} 
              />
              {isResponding && (
                <div className="mt-2 text-center text-sm text-slate-400">
                  Receiving cosmic response...
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default ConnectPage;