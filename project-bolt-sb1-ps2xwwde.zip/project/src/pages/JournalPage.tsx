import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import JournalEntry from '../components/JournalEntry';
import ParticleBackground from '../components/ParticleBackground';
import { JournalEntry as JournalEntryType } from '../types';

const JournalPage: React.FC = () => {
  const [entries, setEntries] = useState<JournalEntryType[]>([]);
  const [newEntry, setNewEntry] = useState('');
  const [newTags, setNewTags] = useState('');
  
  // Load saved entries from localStorage
  useEffect(() => {
    const savedEntries = localStorage.getItem('cosmicJournalEntries');
    if (savedEntries) {
      try {
        const parsedEntries = JSON.parse(savedEntries);
        // Convert string dates back to Date objects
        const processedEntries = parsedEntries.map((entry: any) => ({
          ...entry,
          date: new Date(entry.date)
        }));
        setEntries(processedEntries);
      } catch (error) {
        console.error('Error parsing saved entries:', error);
      }
    }
  }, []);
  
  // Save entries to localStorage when they change
  useEffect(() => {
    localStorage.setItem('cosmicJournalEntries', JSON.stringify(entries));
  }, [entries]);
  
  const handleAddEntry = () => {
    if (newEntry.trim()) {
      const tagsArray = newTags
        .split(',')
        .map(tag => tag.trim())
        .filter(tag => tag.length > 0);
      
      const entry: JournalEntryType = {
        id: uuidv4(),
        content: newEntry,
        date: new Date(),
        tags: tagsArray
      };
      
      setEntries([entry, ...entries]);
      setNewEntry('');
      setNewTags('');
    }
  };
  
  const handleDeleteEntry = (id: string) => {
    setEntries(entries.filter(entry => entry.id !== id));
  };
  
  const handleUpdateEntry = (id: string, content: string) => {
    setEntries(entries.map(entry => 
      entry.id === id ? { ...entry, content } : entry
    ));
  };
  
  return (
    <div className="flex min-h-screen flex-col md:pl-20">
      <ParticleBackground density="low" />
      
      <main className="container mx-auto max-w-4xl flex-1 px-4 py-8">
        <h1 className="mb-8 bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-3xl font-light text-transparent md:text-4xl">
          Cosmic Journal
        </h1>
        
        <div className="mb-8 rounded-xl bg-slate-800/60 p-5 backdrop-blur-md">
          <h2 className="mb-4 text-xl font-medium text-white">New Entry</h2>
          
          <textarea
            value={newEntry}
            onChange={(e) => setNewEntry(e.target.value)}
            className="mb-4 h-32 w-full rounded-lg bg-slate-700/60 p-3 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
            placeholder="Record your insights, experiences, and reflections..."
          />
          
          <div className="mb-4">
            <input
              type="text"
              value={newTags}
              onChange={(e) => setNewTags(e.target.value)}
              className="w-full rounded-lg bg-slate-700/60 p-3 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50"
              placeholder="Tags (comma separated, e.g. insight, meditation, dream)"
            />
          </div>
          
          <button
            onClick={handleAddEntry}
            disabled={!newEntry.trim()}
            className={`rounded-lg bg-gradient-to-r px-4 py-2 font-medium text-white ${
              newEntry.trim()
                ? 'from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700'
                : 'from-slate-600 to-slate-700 cursor-not-allowed opacity-50'
            }`}
          >
            Save Entry
          </button>
        </div>
        
        <div>
          <h2 className="mb-6 text-xl font-medium text-white">Your Entries</h2>
          
          {entries.length === 0 ? (
            <div className="rounded-xl bg-slate-800/40 p-8 text-center backdrop-blur-sm">
              <p className="text-slate-300">
                Your journal is empty. Record your cosmic insights and experiences to see them here.
              </p>
            </div>
          ) : (
            entries.map((entry) => (
              <JournalEntry
                key={entry.id}
                entry={entry}
                onDelete={handleDeleteEntry}
                onUpdate={handleUpdateEntry}
              />
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default JournalPage;